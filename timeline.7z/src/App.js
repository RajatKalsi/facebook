import logo from './logo.svg';
import './App.css';
import UserInterface from './component/UserInterface';
import Modal from './component/modal';
import Api from './component/Api';

function App() {
  return (
    <div className="App">
      {/* <UI /> */}
      {/* <Modal /> */}

      <Api />
    </div>
  );
}

export default App;
